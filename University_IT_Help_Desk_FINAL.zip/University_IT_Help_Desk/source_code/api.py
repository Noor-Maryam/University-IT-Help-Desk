
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from service import classify_ticket

app = FastAPI(
    title="University IT Help Desk API",
    description="API for classifying student IT support tickets",
    version="1.0"
)

class TicketRequest(BaseModel):
    ticket: str = Field(min_length=1, max_length=1000)

@app.post("/analyze")
def analyze_ticket(request: TicketRequest):
    try:
        result = classify_ticket(request.ticket)
        return result

    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    except Exception:
        raise HTTPException(
            status_code=500,
            detail="Internal server error"
        )
