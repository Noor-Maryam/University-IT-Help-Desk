
from pydantic import BaseModel, Field
from typing import Literal

# Allowed categories
Category = Literal[
    "Login & Account Access",
    "Wi-Fi & Network",
    "Software Installation",
    "Hardware Problem",
    "Email Issue",
    "LMS & Portal Issue",
    "Printer Issue",
    "Data & File Access",
    "Security & Phishing",
    "General IT Support"
]

# Keyword rules
keyword_rules = {
    "Login & Account Access": [
        "login", "log in", "password", "username", "account",
        "sign in", "verification code"
    ],
    "Wi-Fi & Network": [
        "wifi", "wi-fi", "internet", "network", "connection",
        "disconnecting", "wireless", "wi fi"
    ],
    "Software Installation": [
        "install", "installation", "software", "update",
        "updating", "application", "setup"
    ],
    "Hardware Problem": [
        "laptop", "keyboard", "battery", "screen", "monitor",
        "computer", "touchpad", "usb ports"
    ],
    "Email Issue": [
        "email", "inbox", "outbox", "messages", "send emails",
        "receiving emails", "attachments"
    ],
    "LMS & Portal Issue": [
        "lms", "portal", "course page", "online quiz",
        "timetable", "attendance", "course materials"
    ],
    "Printer Issue": [
        "printer", "printing", "print", "paper jam",
        "printer queue", "blank pages"
    ],
    "Data & File Access": [
        "file", "files", "folder", "shared drive", "document",
        "deleted", "cloud storage", "access denied"
    ],
    "Security & Phishing": [
        "suspicious", "phishing", "virus", "antivirus",
        "unauthorized", "compromised", "harmful", "security",
        "unfamiliar login"
    ],
    "General IT Support": [
        "projector", "workstation", "technical assistance",
        "computer facilities", "it services",
        "technology facilities", "technical question"
    ]
}

# Keyword classification
def keyword_baseline(ticket):
    ticket = ticket.lower()

    security_keywords = [
        "suspicious", "phishing", "unauthorized",
        "compromised", "virus", "harmful"
    ]

    for keyword in security_keywords:
        if keyword in ticket:
            return "Security & Phishing"

    scores = {}

    for category, keywords in keyword_rules.items():
        score = 0

        for keyword in keywords:
            if keyword in ticket:
                score += 1

        scores[category] = score

    best_category = max(scores, key=scores.get)

    if scores[best_category] == 0:
        return "General IT Support"

    return best_category


# Response validation
class TicketResponse(BaseModel):
    category: Category
    summary: str = Field(min_length=5, max_length=300)


# Main classification service
def classify_ticket(ticket):

    if not ticket or not ticket.strip():
        raise ValueError("Ticket cannot be empty.")

    category = keyword_baseline(ticket)

    summary = f"The student reports: {ticket.strip()}"

    response = {
        "category": category,
        "summary": summary
    }

    validated_response = TicketResponse(**response)

    return validated_response.model_dump()
