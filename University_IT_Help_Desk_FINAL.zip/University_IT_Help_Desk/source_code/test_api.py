
from fastapi.testclient import TestClient
from api import app

client = TestClient(app)

# Test 1: Valid ticket
def test_valid_ticket():
    response = client.post(
        "/analyze",
        json={"ticket": "My campus Wi-Fi keeps disconnecting."}
    )

    assert response.status_code == 200
    assert response.json()["category"] == "Wi-Fi & Network"


# Test 2: Empty ticket
def test_empty_ticket():
    response = client.post(
        "/analyze",
        json={"ticket": ""}
    )

    assert response.status_code == 422


# Test 3: Missing ticket
def test_missing_ticket():
    response = client.post(
        "/analyze",
        json={}
    )

    assert response.status_code == 422


print("Test file created successfully.")
