
import gradio as gr
import requests

API_URL = "http://127.0.0.1:8000/analyze"

def frontend_analyze(ticket):

    if not ticket or not ticket.strip():
        return "Error", "Please enter a ticket."

    try:
        response = requests.post(
            API_URL,
            json={"ticket": ticket},
            timeout=10
        )

        if response.status_code == 200:
            result = response.json()
            return result["category"], result["summary"]

        return "Error", response.json().get("detail", "Request failed.")

    except requests.RequestException:
        return "Error", "Unable to connect to the API."


demo = gr.Interface(
    fn=frontend_analyze,
    inputs=gr.Textbox(
        lines=4,
        label="Enter Student IT Ticket"
    ),
    outputs=[
        gr.Textbox(label="Predicted Category"),
        gr.Textbox(label="Ticket Summary")
    ],
    title="University IT Help Desk Assistant",
    description="Submit a student IT support ticket for classification.",
    submit_btn="Analyze Ticket"
)

if __name__ == "__main__":
    demo.launch()
